extends Control


var reactors = 0 
var reactor_cost = 10 
var reactor_production = 1

var auto_sellers = 0
var auto_seller_cost = 25
var auto_seller_speed = 5


var stored_energy = 0
var max_storage = 100

var credits = 0 

var reactor_upgrade_level = 0 
var storage_upgrade_level = 0 
var seller_upgrade_level = 0 

var reactor_upgrade_cost = 100 
var storage_upgrade_cost = 75
var seller_upgrade_cost = 125


@onready var energy_label = $VBoxContainer/EnergyLabel
@onready var credits_label = $VBoxContainer/Credits
@onready var reactor_label = $VBoxContainer/reactor
@onready var auto_seller_label = $VBoxContainer/AutoSellerLabel


func _on_sell_energy_pressed() -> void:
	credits += stored_energy
	stored_energy = 0
	update_ui()


func _on_tick_timer_timeout() -> void:

	# Energieproduktion berechnen
	var produced_energy = reactors * reactor_production
	# Verkaufskapazität berechnen
	var selling_capacity = auto_sellers * auto_seller_speed
	# Direkt verkaufte Energie
	var directly_sold = min(produced_energy, selling_capacity)
	# Credits durch Direktverkauf
	credits += directly_sold
	# Übrig gebliebene Energie
	var remaining_energy = produced_energy - directly_sold
	# Freien Speicher berechnen
	var available_storage = max_storage - stored_energy
	# Tatsächlich speicherbare Energie
	var accepted_energy = min(remaining_energy, available_storage)
	# Energie speichern
	stored_energy += accepted_energy
	update_ui()


func _on_windmill_pressed() -> void:
	if credits >= reactor_cost:
		credits -= reactor_cost
		reactors += 1 
		update_ui()


func _on_button_pressed() -> void:
	if stored_energy < max_storage:
		stored_energy += 1
	update_ui()


func _on_buy_auto_seller_pressed() -> void:
	if credits >= auto_seller_cost:
		credits -= auto_seller_cost
		auto_sellers += 1
		update_ui()

func _on_reactor_upgrade_pressed() -> void:
	if credits >= reactor_upgrade_cost:
		credits -= reactor_upgrade_cost
		reactor_upgrade_level += 1
		reactor_production += 1
		
		reactor_upgrade_cost += 100
		
		update_ui()

func _on_storage_upgrade_pressed() -> void:
	if credits >= storage_upgrade_cost:
		credits -= storage_upgrade_cost
		storage_upgrade_level += 1
		max_storage += 50
		
		storage_upgrade_cost += 75
		
		update_ui()

func _on_seller_upgrade_pressed() -> void:
	if credits >= seller_upgrade_cost:
		credits -= seller_upgrade_cost
		seller_upgrade_level += 1 
		auto_seller_speed += 5 
		
		seller_upgrade_cost += 75
		
		update_ui()



func update_ui():
	energy_label.text = "Stored Energy: " + str(stored_energy)
	credits_label.text = "Credits: " + str(credits)
	reactor_label.text = "Mini Reactors: " + str(reactors)
	auto_seller_label.text = "Autosellers:" + str(auto_sellers)
